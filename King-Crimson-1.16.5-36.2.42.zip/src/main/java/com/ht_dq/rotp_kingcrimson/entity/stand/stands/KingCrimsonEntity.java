package com.ht_dq.rotp_kingcrimson.entity.stand.stands;

import com.github.standobyte.jojo.entity.stand.StandEntity;
import com.github.standobyte.jojo.entity.stand.StandEntityType;
import net.minecraft.world.World;

public class KingCrimsonEntity extends StandEntity {
    public KingCrimsonEntity(StandEntityType<KingCrimsonEntity> type, World world) {
        super(type, world);
    }
}

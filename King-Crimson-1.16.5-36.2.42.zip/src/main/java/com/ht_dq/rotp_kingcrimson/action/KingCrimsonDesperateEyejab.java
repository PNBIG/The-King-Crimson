import com.github.standobyte.jojo.action.stand.StandEntityHeavyAttack;
import com.github.standobyte.jojo.entity.stand.StandEntity;
import com.github.standobyte.jojo.entity.stand.StandEntityTask;
import com.github.standobyte.jojo.util.mc.damage.StandEntityDamageSource;
import com.ht_dq.rotp_kingcrimson.action.KingCrimsonDesperateEyejab;
import com.ht_dq.rotp_kingcrimson.init.InitEffects;
import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.potion.Effect;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;

public class KingcrimsonEyejabInstance extends StandEntityHeavyAttack.HeavyPunchInstance {

    public KingcrimsonEyejabInstance(StandEntity stand, Entity target, StandEntityDamageSource dmgSource) {
        super(stand, target, dmgSource);
    }

    @Override
    protected void afterAttack(StandEntity stand, Entity target, StandEntityDamageSource dmgSource, StandEntityTask task, boolean hurt, boolean killed) {
        super.afterAttack(stand, target, dmgSource, task, hurt, killed);

        if (hurt && target instanceof LivingEntity) {
            LivingEntity livingTarget = (LivingEntity) target;
            Random random = new Random();

            if (random.nextBoolean()) {
                livingTarget.func_195064_c(new EffectInstance((Effect) InitEffects.HALF_BLINDNESS_LEFT.get(), 140, 0, false, false));
            } else {
                livingTarget.func_195064_c(new EffectInstance((Effect) InitEffects.HALF_BLINDNESS_RIGHT.get(), 140, 0, false, false));
            }

            livingTarget.func_195064_c(new EffectInstance(Effects.field_76421_d, 120, 1, false, false));
            livingTarget.func_195064_c(new EffectInstance(Effects.field_76440_q, 120, 9, false, false));
        }
    }
}




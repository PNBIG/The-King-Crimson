import com.github.standobyte.jojo.action.stand.StandEntityLightAttack;
import com.github.standobyte.jojo.entity.stand.StandEntity;
import com.github.standobyte.jojo.entity.stand.StandEntityTask;
import com.github.standobyte.jojo.init.ModStatusEffects;
import com.github.standobyte.jojo.util.mc.damage.StandEntityDamageSource;
import com.ht_dq.rotp_kingcrimson.action.KingCrimsonChop;
import com.ht_dq.rotp_kingcrimson.init.InitEffects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.potion.Effect;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;

public class KingcrimsonChopInstance extends StandEntityLightAttack.LightPunchInstance {

    public KingcrimsonChopInstance(StandEntity stand, Entity target, StandEntityDamageSource dmgSource) {
        super(stand, target, dmgSource);
    }

    @Override
    protected void afterAttack(StandEntity stand, Entity target, StandEntityDamageSource dmgSource, StandEntityTask task, boolean hurt, boolean killed) {
        super.afterAttack(stand, target, dmgSource, task, hurt, killed);

        if (hurt && target instanceof LivingEntity) {
            LivingEntity livingTarget = (LivingEntity) target;

            livingTarget.func_195064_c(new EffectInstance((Effect) ModStatusEffects.BLEEDING.get(), 120, 2, false, false));
            livingTarget.func_195064_c(new EffectInstance(Effects.field_76421_d, 120, 3, false, false));

            if (target instanceof net.minecraft.entity.player.PlayerEntity) {
                livingTarget.func_195064_c(new EffectInstance((Effect) InitEffects.MANGLED_BODY.get(), 120, 0, false, false));
            }
        }
    }
}



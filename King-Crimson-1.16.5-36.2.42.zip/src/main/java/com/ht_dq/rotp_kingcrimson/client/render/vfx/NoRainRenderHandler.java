package com.ht_dq.rotp_kingcrimson.client.render.vfx;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ActiveRenderInfo;
import net.minecraft.client.world.ClientWorld;
import net.minecraftforge.client.IWeatherParticleRenderHandler;

public class NoRainRenderHandler implements IWeatherParticleRenderHandler {
    @Override
    public void render(int i, ClientWorld clientWorld, Minecraft minecraft, ActiveRenderInfo activeRenderInfo) {
    }
}
